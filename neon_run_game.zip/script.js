const canvas = document.getElementById("game-canvas");
const ctx = canvas.getContext("2d");
const $ = id => document.getElementById(id);
const W = canvas.width, H = canvas.height;
const keys = new Set();
let state = "menu", paused = false, last = 0, camera = 0, sector = 1;
let crystals = 0, lives = 3, distance = 0, toastTimer = 0, invulnerable = 0;
const gravity = 0.62;
const player = {x:70,y:300,w:27,h:42,vx:0,vy:0,onGround:false,facing:1,run:0};
let platforms = [], gems = [], hazards = [], drones = [], exit = null, worldWidth = 3000;
let sectorGems = 0, collectedThisSector = 0;

function rand(seed) { let x = Math.sin(seed * 127.1 + sector * 311.7) * 43758.5453; return x - Math.floor(x); }
function buildLevel(n) {
  sector = n; camera = 0; distance = 0; collectedThisSector = 0;
  worldWidth = 2850 + n * 260;
  platforms = [{x:0,y:470,w:400,h:70},{x:480,y:430,w:180,h:110},{x:720,y:390,w:155,h:150}];
  let x = 930;
  let seed = 1;
  while (x < worldWidth - 300) {
    const gap = 65 + rand(seed++) * (n > 2 ? 100 : 75);
    const width = 105 + rand(seed++) * 125;
    const y = 340 + rand(seed++) * 115;
    platforms.push({x:x+gap,y,w:width,h:H-y+70});
    x += gap + width;
  }
  platforms.push({x:worldWidth-220,y:390,w:220,h:150});
  gems = [];
  const gemCount = 18 + n * 3;
  for (let i=0;i<gemCount;i++) {
    const p = platforms[2 + Math.floor(rand(i+50) * Math.max(1,platforms.length-3))];
    gems.push({x:p.x+25+rand(i+99)*Math.max(10,p.w-45),y:p.y-25-rand(i+111)*40,r:8,got:false,phase:rand(i+17)*6});
  }
  hazards = [];
  drones = [];
  for (let i=0;i<7+n;i++) {
    const p = platforms[3 + Math.floor(rand(i+400)*Math.max(1,platforms.length-4))];
    hazards.push({x:p.x+25+rand(i+500)*Math.max(15,p.w-45),y:p.y-12,w:24,h:12,kind: i%3===0 ? "spike" : "laser",active:true,phase:rand(i+600)*6});
  }
  for (let i=0;i<2+n;i++) {
    const p = platforms[2 + Math.floor(rand(i+800)*Math.max(1,platforms.length-3))];
    drones.push({x:p.x+20,y:p.y-65-rand(i+900)*55,originX:p.x+20,range:50+rand(i+910)*55,phase:rand(i+920)*6,w:30,h:18});
  }
  exit={x:worldWidth-125,y:310,w:48,h:80,open:false};
  sectorGems = gems.length;
  player.x=65; player.y=370; player.vx=0; player.vy=0; player.onGround=false;
  $("sector").textContent=String(n).padStart(2,"0");
  $("mission").textContent=n===5?"НАМЕРИ ЯДРОТО":"НАМЕРИ ИЗХОДА";
  $("objective").textContent=n===5?"ЦЕЛ: ДОСТИГНИ ДО ЯДРОТО":"ЦЕЛ: СТИГНИ ДО ПОРТАЛА";
  updateHUD();
}
function updateHUD() {
  $("crystals").textContent=crystals; $("hp").textContent=lives;
  $("distance").textContent=Math.max(0,Math.floor(player.x/10))+" m";
}
function showToast(text) {
  $("toast").textContent=text; $("toast").classList.add("show"); toastTimer=1.8;
}
function startGame() {
  state="game"; paused=false; lives=3; crystals=0; buildLevel(1);
  $("menu").classList.add("hidden"); $("game").classList.remove("hidden");
  $("pause-overlay").classList.add("hidden"); $("result-overlay").classList.add("hidden");
  last=performance.now(); requestAnimationFrame(loop);
}
function togglePause(force) {
  if(state!=="game")return;
  paused=typeof force==="boolean"?force:!paused;
  $("pause-overlay").classList.toggle("hidden",!paused);
  if(!paused){last=performance.now();requestAnimationFrame(loop);}
}
function endSector(won) {
  state="result";
  $("result-overlay").classList.remove("hidden");
  $("result-icon").textContent=won?"✦":"⚠";
  $("result-icon").style.color=won?"var(--green)":"var(--pink)";
  $("result-title").textContent=won?(sector===5?"АКАДЕМИЯТА Е СПАСЕНА":"СЕКТОР ИЗЧИСТЕН"):"МИСИЯТА СЕ ПРОВАЛИ";
  $("result-text").textContent=won?(sector===5?"Изключи централното ядро и избяга от Академията на сенките!":"Стигна до портала. Следващият сектор е още по-опасен."):"Дроновете те настигнаха. Опитай нов маршрут и пази животите си.";
  $("result-crystals").textContent=crystals;
  let best=Number(localStorage.getItem("neonRunBest")||0);
  if(won && crystals>best){best=crystals;localStorage.setItem("neonRunBest",String(best));}
  $("result-best").textContent=best;
  $("next-btn").style.display=won&&sector<5?"block":"none";
  $("next-btn").textContent=sector===4?"ПОСЛЕДЕН СЕКТОР →":"СЛЕДВАЩ СЕКТОР →";
  $("again-btn").textContent=won&&sector===5?"ИГРАЙ ОТНОВО":"ОТНАЧАЛО";
}
function hurt() {
  if(invulnerable>0)return;
  lives--; invulnerable=1.5; player.vy=-7; player.vx=-player.facing*4;
  showToast(lives>0?"УДАР! ВНИМАВАЙ.":"СИСТЕМАТА ТЕ ЗАСЕЧЕ");
  updateHUD();
  if(lives<=0)setTimeout(()=>{if(state==="game")endSector(false)},350);
}
function update(dt) {
  if(state!=="game"||paused)return;
  dt=Math.min(dt,0.033);
  if(invulnerable>0)invulnerable-=dt;
  if(toastTimer>0){toastTimer-=dt;if(toastTimer<=0)$("toast").classList.remove("show");}
  const left=keys.has("ArrowLeft")||keys.has("a")||keys.has("A");
  const right=keys.has("ArrowRight")||keys.has("d")||keys.has("D");
  const sprint=keys.has("Shift");
  const speed=sprint?5.6:3.8;
  if(left){player.vx=-speed;player.facing=-1;} else if(right){player.vx=speed;player.facing=1;} else player.vx*=0.78;
  if((keys.has(" ")||keys.has("ArrowUp")||keys.has("w")||keys.has("W"))&&player.onGround){player.vy=-12.6;player.onGround=false;}
  player.vy+=gravity; player.vy=Math.min(player.vy,14);
  const oldY=player.y;
  player.x+=player.vx; player.y+=player.vy; player.onGround=false;
  for(const p of platforms){
    if(player.x+player.w>p.x&&player.x<p.x+p.w&&oldY+player.h<=p.y+4&&player.y+player.h>=p.y&&player.vy>=0){
      player.y=p.y-player.h;player.vy=0;player.onGround=true;
    }
  }
  player.x=Math.max(0,Math.min(worldWidth-player.w,player.x));
  if(player.y>H+100){hurt();player.y=300;player.x=Math.max(20,player.x-100);}
  for(const g of gems){if(!g.got&&Math.hypot(player.x+player.w/2-g.x,player.y+player.h/2-g.y)<25){g.got=true;crystals++;collectedThisSector++;showToast("+1 ЕНЕРГИЕН КРИСТАЛ");updateHUD();}}
  for(const h of hazards){
    h.phase+=dt*2;
    const active=h.kind==="laser"?(Math.sin(h.phase)>-0.15):true;
    h.active=active;
    if(active&&player.x+player.w>h.x-5&&player.x<h.x+h.w+5&&player.y+player.h>h.y-5&&player.y<h.y+h.h+6)hurt();
  }
  for(const d of drones){
    d.phase+=dt*1.8;d.x=d.originX+Math.sin(d.phase)*d.range;d.y+=Math.sin(d.phase*1.4)*0.35;
    if(player.x+player.w>d.x&&player.x<d.x+d.w&&player.y+player.h>d.y&&player.y<d.y+d.h)hurt();
  }
  exit.open=player.x>worldWidth-600;
  if(player.x+player.w>exit.x&&player.x<exit.x+exit.w&&player.y+player.h>exit.y&&player.y<exit.y+exit.h){
    if(sector<5)endSector(true);else endSector(true);
  }
  camera=Math.max(0,Math.min(worldWidth-W,player.x-W*0.35));
  updateHUD();
}
function rect(x,y,w,h,color){ctx.fillStyle=color;ctx.fillRect(Math.round(x),Math.round(y),Math.round(w),Math.round(h));}
function draw() {
  ctx.clearRect(0,0,W,H);
  const sky=ctx.createLinearGradient(0,0,0,H);sky.addColorStop(0,"#111735");sky.addColorStop(.6,"#432450");sky.addColorStop(1,"#101529");ctx.fillStyle=sky;ctx.fillRect(0,0,W,H);
  // stars
  for(let i=0;i<75;i++){let x=((i*137-camera*.12)%W+W)%W;let y=(i*71)%300;rect(x,y,2,2,i%5===0?"#ff72d2":"#9cbeff");}
  // distant skyline
  for(let i=0;i<24;i++){let x=((i*90-camera*.25)% (W+100)+W+100)%(W+100)-30;let h=70+(i*47)%150;rect(x,430-h,45,h,"#1a2045");for(let wy=430-h+12;wy<420;wy+=18)for(let wx=x+8;wx<x+38;wx+=14)if((i+wx+wy)%3>0)rect(wx,wy,4,6,"#5d4b9a");}
  // neon moon
  ctx.fillStyle="#b7a4ff";ctx.shadowBlur=30;ctx.shadowColor="#ad8aff";ctx.beginPath();ctx.arc(790,90,36,0,Math.PI*2);ctx.fill();ctx.shadowBlur=0;
  // background grid
  ctx.strokeStyle="#53dfff1c";ctx.lineWidth=1;for(let x=-(camera%40);x<W;x+=40){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x,H);ctx.stroke();}
  // platforms
  for(const p of platforms){let x=p.x-camera;if(x+p.w<0||x>W)continue;rect(x,p.y,p.w,p.h,"#10182d");rect(x,p.y,p.w,5,"#54f5ff");rect(x,p.y+5,p.w,2,"#a14fff");for(let xx=x+10;xx<x+p.w-5;xx+=24)rect(xx,p.y+17,2,Math.min(25,p.h-20),"#27375d");}
  // gems
  for(const g of gems){if(g.got)continue;let x=g.x-camera;ctx.save();ctx.translate(x,g.y+Math.sin(performance.now()/250+g.phase)*4);ctx.rotate(Math.PI/4);ctx.shadowBlur=18;ctx.shadowColor="#54f5ff";rect(-6,-6,12,12,"#54f5ff");rect(-3,-3,6,6,"#e5ffff");ctx.restore();ctx.shadowBlur=0;}
  // hazards
  for(const h of hazards){let x=h.x-camera;if(x<-40||x>W+40)continue;if(h.kind==="spike"){ctx.fillStyle="#ff4e91";ctx.shadowBlur=12;ctx.shadowColor="#ff4e91";ctx.beginPath();ctx.moveTo(x,h.y+h.h);ctx.lineTo(x+h.w/2,h.y-8);ctx.lineTo(x+h.w,h.y+h.h);ctx.fill();ctx.shadowBlur=0;}else if(h.active){rect(x,h.y,h.w,h.h,"#ff376e");rect(x-4,h.y+4,h.w+8,2,"#ffaccd");}}
  // drones
  for(const d of drones){let x=d.x-camera;if(x<-50||x>W+50)continue;ctx.shadowBlur=18;ctx.shadowColor="#ff4ecb";rect(x,d.y,d.w,d.h,"#d83f9c");rect(x+5,d.y+5,d.w-10,5,"#ffe4fb");rect(x-5,d.y+6,5,4,"#ff8bdc");rect(x+d.w,d.y+6,5,4,"#ff8bdc");ctx.shadowBlur=0;}
  // portal
  let ex=exit.x-camera;ctx.save();ctx.shadowBlur=exit.open?30:15;ctx.shadowColor=exit.open?"#9bffbf":"#ff4ecb";ctx.strokeStyle=exit.open?"#9bffbf":"#ff4ecb";ctx.lineWidth=4;ctx.beginPath();ctx.ellipse(ex+exit.w/2,exit.y+exit.h/2,exit.w/2,exit.h/2,0,0,Math.PI*2);ctx.stroke();ctx.fillStyle=exit.open?"#9bffbf20":"#ff4ecb18";ctx.fill();ctx.restore();rect(ex+exit.w/2-2,exit.y+15,4,exit.h-30,exit.open?"#9bffbf":"#ff4ecb");
  // player
  const px=player.x-camera,py=player.y;
  if(invulnerable<=0||Math.floor(performance.now()/100)%2===0){
    ctx.shadowBlur=15;ctx.shadowColor="#54f5ff";
    rect(px+6,py,16,13,"#0a1025");rect(px+5,py+4,18,9,"#273b66");rect(px+3,py+14,22,19,"#1b4d7a");rect(px+3,py+14,22,4,"#54f5ff");rect(px+(player.facing>0?18:2),py+5,7,4,"#ff4ecb");
    rect(px+5,py+31,7,10,"#10172d");rect(px+16,py+31,7,10,"#10172d");rect(px+(player.facing>0?-6:24),py+17,9,4,"#ff4ecb");ctx.shadowBlur=0;
  }
  // in-game prompt
  if(exit.open){ctx.fillStyle="#9bffbf";ctx.font="bold 12px Orbitron";ctx.fillText("ПОРТАЛЪТ Е ОТВОРЕН!",W-235,35);}
  ctx.fillStyle="#ffffff8a";ctx.font="10px monospace";ctx.fillText("X "+Math.floor(player.x)+" / "+worldWidth,18,H-17);
}
function loop(now) {
  if(state!=="game"||paused)return;
  const dt=(now-last)/1000;last=now;update(dt);draw();
  if(state==="game"&&!paused)requestAnimationFrame(loop);
}
window.addEventListener("keydown",e=>{
  if(["ArrowLeft","ArrowRight","ArrowUp"," "].includes(e.key))e.preventDefault();
  keys.add(e.key);
  if(e.key==="Escape"&&state==="game")togglePause();
});
window.addEventListener("keyup",e=>keys.delete(e.key));
$("play-btn").addEventListener("click",startGame);
$("pause-btn").addEventListener("click",()=>togglePause());
$("resume-btn").addEventListener("click",()=>togglePause(false));
$("quit-btn").addEventListener("click",()=>{state="menu";paused=false;$("game").classList.add("hidden");$("menu").classList.remove("hidden");$("pause-overlay").classList.add("hidden");});
$("again-btn").addEventListener("click",startGame);
$("next-btn").addEventListener("click",()=>{if(sector<5){state="game";$("result-overlay").classList.add("hidden");buildLevel(sector+1);last=performance.now();requestAnimationFrame(loop);}else startGame();});
buildLevel(1);draw();
